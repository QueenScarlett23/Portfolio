package com.a19013147.myapplication;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import java.util.List;

public class IntentHelper {

        public static void openIntent(Context context, Class passTo) {
            // declares intent and class to pass value on
            Intent i = new Intent(context, passTo);

            // start the activity
            context.startActivity(i);
        }

    public static void openIntent(Context context, Class passTo, String variable1, String value1, String variable2, String value2, String variable3, boolean value3, String variable4, boolean value4) {
        // declares intent and class to pass value on
        Intent i = new Intent(context, passTo);

        // pass through string value with key word "order" (used code from before)
        i.putExtra(variable1, value1); // puts data into variables
        i.putExtra(variable2, value2); // puts data into variables
        i.putExtra(variable3, value3); // puts data into variables
        i.putExtra(variable4, value4); // puts data into variables

        // start the activity
        context.startActivity(i);
    }

    public static void openIntent(Context context, Class passTo, String variable, String value, String variable2, String value2, String variable3, String value3) {
        // declares intent and class to pass value on
        Intent i = new Intent(context, passTo);

        // pass through string value with key word "order" (used code from before)
        i.putExtra(variable, value); // puts data into variables
        i.putExtra(variable2, value2);
        i.putExtra(variable3, value3);


        // start the activity
        context.startActivity(i);
    }

    public static void openIntent(Context context, Class passTo, String variable, String value) {
        // declares intent and class to pass value on
        Intent i = new Intent(context, passTo);

        // pass through string value with key word "order" (used code from before)
        i.putExtra(variable, value); // puts data into variables

        // start the activity
        context.startActivity(i);
    }

    public static void openIntent(Context context, Class passTo, List<String> variable, List<String> value) {
        // declares intent and class to pass value on
        Intent i = new Intent(context, passTo);

        // pass through string value with key word "order" (used code from before)
        for (int in = 0; in < variable.size(); in++) {
            i.putExtra(variable.get(in), value.get(in)); // puts data into variables
        }

        // start the activity
        context.startActivity(i);
    }

    public static void openIntent(Context context, Class passTo, String variable, boolean value) {
        // declares intent and class to pass value on
        Intent i = new Intent(context, passTo);

        // pass through string value with key word "order" (used code from before)
        i.putExtra(variable, value); // puts data into variables

        // start the activity
        context.startActivity(i);
    }

    public static void openIntentLogin(Context context) {
        // declares intent and class to pass value on
        Intent i = new Intent(context, MainActivity.class);

        // start the activity
        context.startActivity(i);
        

    }

    // Old code ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public static void shareIntent(Context context, String order) {
        Intent sendIntent = new Intent();

        // set action to send
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, order);
        // sending plain text
        sendIntent.setType("text/plain");
        // show share sheet
        Intent shareIntent = Intent.createChooser(sendIntent, null);
        context.startActivity(shareIntent);
    }

    public static void shareIntent(Context context, String productName, String customerName, String customerCell) {
        Intent sendIntent = new Intent(Intent.ACTION_SEND);

        Bundle shareOrderDetails = new Bundle();
        shareOrderDetails.putString("productName", productName);
        shareOrderDetails.putString("customerName", customerName);
        shareOrderDetails.putString("customerCell", customerCell);

        sendIntent.putExtra(Intent.EXTRA_TEXT, shareOrderDetails);
        sendIntent.setType("text/plain");

        Intent shareIntent = Intent.createChooser(sendIntent, null);
        context.startActivity(shareIntent);
    }
}
