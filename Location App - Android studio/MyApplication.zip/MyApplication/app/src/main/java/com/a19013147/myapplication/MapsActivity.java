package com.a19013147.myapplication;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.ColorRes;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.AsyncQueryHandler;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.directions.route.AbstractRouting;
import com.directions.route.Route;
import com.directions.route.RouteException;
import com.directions.route.Routing;
import com.directions.route.RoutingListener;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.FirebaseDatabase;

import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MapsActivity extends AppCompatActivity
        implements
        OnMapReadyCallback,
        NavigationView.OnNavigationItemSelectedListener,
        GoogleApiClient.OnConnectionFailedListener,
        RoutingListener {

    GoogleMap mMap;
    private DrawerLayout drawer;
    Location currentLocation;
    Location destinationLocation = null;
    FusedLocationProviderClient fusedLocationClient;
    SupportMapFragment mapFrag;
    LocationRequest locationRequest;
    Marker currentLocationMarker;
    User user;
    Spinner typeSpn;
    Button findBtn;
    TextView distanceTV;
    TextView durationTV;
    ProgressBar pBar;


    protected LatLng start = null;
    protected LatLng end = null;

    private List<Polyline> polylines = null;

    String[] infoList;

    String[] placeTypeList = {
            "amusement_park",
            "aquarium",
            "art_gallery",
            "casino",
            "cemetery",
            "church",
            "courthouse",
            "embassy",
            "hindu_temple",
            "hospital",
            "local_government_office",
            "mosque",
            "museum",
            "park",
            "stadium",
            "shopping_mall",
            "subway_station",
            "transit_station",
            "tourist_attraction",
            "university",
            "zoo"};
    String[] placeNameList = {
            "Amusement park",
            "Aquarium",
            "Art gallery",
            "Casino",
            "Cemetery",
            "Church",
            "Courthouse",
            "Embassy",
            "Hindu temple",
            "Hospital",
            "Local government office",
            "Mosque",
            "Museum",
            "Park",
            "Stadium",
            "Shopping mall",
            "Subway station",
            "Transit station",
            "Tourist attraction",
            "University",
            "Zoo"};

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;

    @RequiresApi(api = Build.VERSION_CODES.N)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        //getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new MapsActivity().mapFrag).commit();

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        typeSpn = findViewById(R.id.sp_type);
        typeSpn.setBackgroundColor(Color.MAGENTA);
        findBtn = findViewById(R.id.bt_find);

        pBar = findViewById(R.id.progressBarMap);

        typeSpn.setAdapter(new ArrayAdapter<>(MapsActivity.this,
                android.R.layout.simple_spinner_dropdown_item, placeNameList));

        distanceTV = findViewById(R.id.tv_Distance);

        durationTV = findViewById(R.id.tv_Time);

        /*if (savedInstanceState == null) {
            Bundle extras = getIntent().getExtras();
            if(extras == null) {
                IntentHelper.openIntent(MapsActivity.this, LoginActivity.class);
            } else {
                String name = extras.getString(LoginActivity.NAME);
                String email = extras.getString(LoginActivity.EMAIL);
                boolean nightmode = extras.getBoolean(LoginActivity.NIGHTMODE);
                boolean metric = extras.getBoolean(LoginActivity.METRIC);

                user = new User(name, email, nightmode, metric);
            }
        } else {
            String name = (String) savedInstanceState.getSerializable(LoginActivity.NAME);
            String email = (String) savedInstanceState.getSerializable(LoginActivity.EMAIL);
            boolean nightmode = (boolean) savedInstanceState.getSerializable(LoginActivity.NIGHTMODE);
            boolean metric = (boolean) savedInstanceState.getSerializable(LoginActivity.METRIC);

            user = new User(name, email, nightmode, metric);
        }*/
        user = GetUser();

        Toast.makeText(this, "Welcome " + user.Name + "!", Toast.LENGTH_SHORT).show();

        checkLocationPermission();


        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        mapFrag = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFrag.getMapAsync(this);

        findBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int i = typeSpn.getSelectedItemPosition();

                //Toast.makeText(MapsActivity.this, placeTypeList[i].toString(), Toast.LENGTH_LONG).show();
                String placeUrl = "https://maps.googleapis.com/maps/api/place/nearbysearch/json"
                        + "?location=" + currentLocation.getLatitude() + "," + currentLocation.getLongitude()
                        + "&radius=100000" + "&types=" + placeTypeList[i] + "&fields=name%2Cformatted_address%2Crating%2Copening_hours" + "&sensor=true"
                        + "&key=" + getResources().getString(R.string.map_key);

                new PlaceTask().execute(placeUrl);
            }
        });

    }



    private void FindRoutes(LatLng start, LatLng end) {
        if (start == null || end == null) {
            Toast.makeText(MapsActivity.this, "Unable to get location", Toast.LENGTH_LONG).show();
        } else {

            Routing routing = new Routing.Builder()
                    .travelMode(AbstractRouting.TravelMode.DRIVING)
                    .withListener(this)
                    .alternativeRoutes(true)
                    .waypoints(start, end)
                    .key(getResources().getString(R.string.map_key))  //also define your api key here.
                    .build();
            routing.execute();
        }
    }

    private User GetUser() {
        String name = GetStrFromPrefs(LoginActivity.NAME),
                email = GetStrFromPrefs(LoginActivity.EMAIL);
        boolean night = GetBoolFromPrefs(LoginActivity.NIGHTMODE),
                metr = GetBoolFromPrefs(LoginActivity.METRIC);

        return new User(name, email, night, metr);
    }

    public boolean GetBoolFromPrefs(String s) {
        SharedPreferences sharedPref = this.getSharedPreferences("com.a19013147.myapplication", Context.MODE_PRIVATE);
        return sharedPref.getBoolean(s, false);
    }

    private String GetStrFromPrefs(String s) {
        SharedPreferences sharedPref = this.getSharedPreferences("com.a19013147.myapplication", Context.MODE_PRIVATE);
        return sharedPref.getString(s, "");
    }

    @Override
    public void onPause() {
        super.onPause();

        //stop location updates when this activity is not active
        if (fusedLocationClient != null) {
            fusedLocationClient.removeLocationUpdates(locationCallback);
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);

        locationRequest = new LocationRequest();
        locationRequest.setInterval(5000);
        locationRequest.setFastestInterval(3000);
        locationRequest.setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                //Location permission granted
                fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.myLooper());
                mMap.setMyLocationEnabled(true);
            } else {
                //Request permission
                checkLocationPermission();
            }
        } else {
            fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.myLooper());
            mMap.setMyLocationEnabled(true);
        }

        mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(@NonNull Marker marker) {

                if (!marker.getTitle().toString().equals("Current Location")) {

                    AlertDialog.Builder builder = new AlertDialog.Builder(MapsActivity.this);
                    builder.setMessage(marker.getSnippet())

                            .setTitle("Selected Landmark")
                            .setPositiveButton(R.string.marker_directions, new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    // DIRECTIONS
                                    LatLng markerLocation = new LatLng(marker.getPosition().latitude, marker.getPosition().longitude);
                                    start = new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude());
                                    end = markerLocation;

                                    mMap.clear();

                                    FindRoutes(start, end);
                                    CalculateDistanceInMeters(marker);
                                }
                            })
                            .setNeutralButton(R.string.marker_add_to_favourite, new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    // FAVOURITE
                                    // set icon
                                    marker.setIcon(BitmapDescriptorFactory.fromResource(R.drawable.favouritelocation_dropper));
                                    String info = marker.getSnippet();
                                    String placeID = marker.getTitle();
                                    user.SaveLocation(placeID, info, marker.getPosition());
                                    PushToDataBase();
                                    //user.AddFavourite();
                                }
                            })
                            /*.setNegativeButton(R.string.marker_info, new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    // INFO
                                    marker.getSnippet();
                                    marker.showInfoWindow();
                                }

                            })*/;
                    // Create the AlertDialog object and return it
                    builder.create().show();
                }
                return true;
            }
        });

        moveCameraToNewPos = true;

        // update user info
        GetUserData();
    }

    private int CalculateTime(float distance) {
        int speedIs1000MetresPerMinute = 870;
        float estimatedDurationTime = distance / speedIs1000MetresPerMinute;

        return (int) estimatedDurationTime;
    }

    private void CalculateDistanceInMeters(Marker marker) {
        float results[] = new float[10];
        Location.distanceBetween(currentLocation.getLatitude(), currentLocation.getLongitude(), marker.getPosition().latitude, marker.getPosition().longitude, results);
        double d = 0;

        if (user.metric) {
            // metric
            d = results[0] / 1000;
        } else {
            //impiricle
            // miles = meters × 0.000621
            d = results[0] * 0.000621;
        }

        DecimalFormat df = new DecimalFormat("#.##");
        //System.out.print(df.format(d));

        String distance = df.format(d);
        String time = CalculateTime(results[0]) + "";

        if (user.metric) {
            // metric
            distanceTV.setText(distance + " km");
            durationTV.setText(time + " min");
        } else {
            // not metric
            distanceTV.setText(distance + " mi");
            durationTV.setText(time + " min");
        }
    }

    LatLng userLocation;
    boolean moveCameraToNewPos;

    LocationCallback locationCallback = new LocationCallback() {
        @Override
        public void onLocationResult(@NonNull LocationResult locationResult) {
            List<Location> locationList = locationResult.getLocations();
            if (locationList.size() > 0) {
                //last location in list is newest
                Location location = locationList.get(locationList.size() - 1);
                Log.i("MapsActivity", "Location: " + location.getLatitude() + " " + location.getLongitude());
                currentLocation = location;
                if (currentLocationMarker != null) {
                    currentLocationMarker.remove();
                }

                //Place current location marker
                userLocation = new LatLng(location.getLatitude(), location.getLongitude());
                MarkerOptions markerOptions = new MarkerOptions();
                markerOptions.position(userLocation);
                markerOptions.title("Current Location");
                //markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_MAGENTA));
                markerOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.currentlocation_dropper));
                currentLocationMarker = mMap.addMarker(markerOptions);

                if (moveCameraToNewPos) {
                    moveCameraToPoition();
                    moveCameraToNewPos = false;
                }
            }
        }
    };

    private void moveCameraToPoition() {
        //move map camera
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 10));
    }


    private void checkLocationPermission() {

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)) {

                /*new AlertDialog.Builder(this).setTitle("Location Permission Needed")
                        .setMessage("This app needs the Location permission, press accept to allow location accessibility")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                ActivityCompat.requestPermissions(MapsActivity.this,
                                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
                            }
                        }).create().show();*/

            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        LOCATION_PERMISSION_REQUEST_CODE);
            }
        } {
            new AlertDialog.Builder(this).setTitle("Location Permission Needed")
                    .setMessage("This app needs the Location permission, press accept to allow location accessibility")
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions(MapsActivity.this,
                                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
                        }
                    }).create().show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case LOCATION_PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (ContextCompat.checkSelfPermission(this,
                            Manifest.permission.ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED) {
                        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.myLooper());
                        mMap.setMyLocationEnabled(true);
                    }
                } else {
                    Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
                }
                return;
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            case R.id.nav_settings:
                IntentHelper.openIntent(this, Settings.class);
                break;
            case R.id.nav_share:
                Toast.makeText(this, "Share", Toast.LENGTH_SHORT).show();
                break;
            case R.id.nav_logout:
                Logout();
                break;
        }

        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    void Logout() {
        // resetting user prefs
        SharedPreferences sharedPref = this.getSharedPreferences("com.a19013147.myapplication", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();

        editor.putBoolean(LoginActivity.LOGGED, false);
        editor.putString(LoginActivity.NAME, "");
        editor.putString(LoginActivity.EMAIL, "");
        editor.putBoolean(LoginActivity.NIGHTMODE, false);
        editor.putBoolean(LoginActivity.METRIC, false);

        editor.apply();
        editor.commit();
        // loging out mAuth
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        mAuth.signOut();

        // goinmg to login screen
        IntentHelper.openIntent(this, LoginActivity.class);
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        FindRoutes(start, end);

    }

    @Override
    public void onRoutingFailure(RouteException e) {
        View parentLayout = findViewById(android.R.id.content);
        Snackbar snackbar = Snackbar.make(parentLayout, e.toString(), Snackbar.LENGTH_LONG);
        snackbar.show();

    }

    @Override
    public void onRoutingStart() {
        Toast.makeText(MapsActivity.this, "Calculating Route...", Toast.LENGTH_LONG).show();

    }

    @Override
    public void onRoutingSuccess(ArrayList<Route> route, int shortestRouteIndex) {
        CameraUpdate center = CameraUpdateFactory.newLatLng(start);
        CameraUpdate zoom = CameraUpdateFactory.zoomTo(16);
        if (polylines != null) {
            polylines.clear();
        }
        PolylineOptions polyOptions = new PolylineOptions();
        LatLng polylineStartLatLng = null;
        LatLng polylineEndLatLng = null;


        polylines = new ArrayList<>();

        for (int i = 0; i < route.size(); i++) {

            if (i == shortestRouteIndex) {
                polyOptions.width(7);
                polyOptions.addAll(route.get(shortestRouteIndex).getPoints());
                Polyline polyline = mMap.addPolyline(polyOptions);
                polylineStartLatLng = polyline.getPoints().get(0);
                int k = polyline.getPoints().size();
                polylineEndLatLng = polyline.getPoints().get(k - 1);
                polylines.add(polyline);

            } else {

            }

        }

        //Add Marker on route starting position
        MarkerOptions startMarker = new MarkerOptions();
        startMarker.position(polylineStartLatLng);
        startMarker.title("My Location");
        mMap.addMarker(startMarker);

        //Add Marker on route ending position
        MarkerOptions endMarker = new MarkerOptions();
        endMarker.position(polylineEndLatLng);
        endMarker.title("Destination");
        mMap.addMarker(endMarker);

    }

    @Override
    public void onRoutingCancelled() {
        FindRoutes(start, end);

    }


    private class PlaceTask extends AsyncTask<String, Integer, String> {
        @Override
        protected String doInBackground(String... strings) {
            String data = null;
            try {
                data = downloadUrl(strings[0]);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return data;
        }

        @Override
        protected void onPostExecute(String s) {

            new ParserTask().execute(s);
            //Toast.makeText(MapsActivity.this, s, Toast.LENGTH_LONG).show();
        }
    }

    private String downloadUrl(String string) throws IOException {

        URL url = new URL(string);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.connect();
        InputStream stream = connection.getInputStream();
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
        StringBuilder builder = new StringBuilder();
        String line = "";

        while ((line = reader.readLine()) != null) {
            builder.append(line);
        }

        String data = builder.toString();
        reader.close();
        return data;
    }

    private class ParserTask extends AsyncTask<String, Integer, List<HashMap<String, String>>> {

        @Override
        protected List<HashMap<String, String>> doInBackground(String... strings) {

            JsonParser jsonParser = new JsonParser();
            List<HashMap<String, String>> mapList = null;
            JSONObject object = null;
            try {
                object = new JSONObject(strings[0]);
                mapList = jsonParser.parseResult(object);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return mapList;
        }

        @Override
        protected void onPostExecute(List<HashMap<String, String>> hashMaps) {
            mMap.clear();

            for (int i = 0; i < hashMaps.size(); i++) {
                HashMap<String, String> hashMapList = hashMaps.get(i);
                String placeID = hashMapList.get("place_id");
                if (!user.IsLocationSaved(placeID)) { // if location is not saved

                    double lat = Double.parseDouble(hashMapList.get("lat"));
                    double lng = Double.parseDouble(hashMapList.get("lng"));
                    String name = hashMapList.get("name");
                    String rating = hashMapList.get("rating");
                    String openingHours = hashMapList.get("opening_hours");

                    String openOrClosed = "";
                    if (openingHours == "false") {
                        openOrClosed = "Closed";
                    } else if (openingHours == "null") {
                        openOrClosed = "Open";
                    } else {
                        openOrClosed = "Open";
                    }

                    LatLng latLng = new LatLng(lat, lng);
                    MarkerOptions options = new MarkerOptions();
                    options.position(latLng);
                    options.title(placeID);
                    options.snippet(name + "\n" +
                            "Rating: " + rating + "\n" +
                            "Status: " + openOrClosed);
                    options.icon(BitmapDescriptorFactory.fromResource(R.drawable.location_dropper));

                    mMap.addMarker(options);
                }
            }

            DisplayFavouriteLocations();
        }
    }


    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    void PushToDataBase() {
        pBar.setVisibility(View.VISIBLE);

        FirebaseDatabase.getInstance().getReference("Users")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    Toast.makeText(MapsActivity.this, "Favourite locations saved successfully", Toast.LENGTH_LONG).show();
                    pBar.setVisibility(View.GONE);

                } else {
                    Toast.makeText(MapsActivity.this, "Unable to save favourite locations. Try again", Toast.LENGTH_LONG).show();
                    pBar.setVisibility(View.GONE);
                }

            }
        });
    }

    void GetUserData() {
        pBar.setVisibility(View.VISIBLE);

        FirebaseDatabase.getInstance().getReference("Users")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                .get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                pBar.setVisibility(View.GONE);
                if (task.isSuccessful()) {
                    DataSnapshot ds = task.getResult();
                    User userData = ds.getValue(User.class);
                    user = userData;
                    Toast.makeText(MapsActivity.this, "Local details updated", Toast.LENGTH_LONG).show();

                    DisplayFavouriteLocations();

                } else {
                    Toast.makeText(MapsActivity.this, "Unable to load Favourite locations. Try again!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    void DisplayFavouriteLocations() {
        if (user.FavouriteLocations != null)
            if (user.FavouriteLocations.size() > 0)
                for (SavedLocation sl : user.FavouriteLocations) {
                    MarkerOptions options = new MarkerOptions();
                    options.title(sl.placeID);
                    options.snippet(sl.info);
                    LatLng ll = new LatLng(sl.position_lat, sl.position_lng);
                    options.position(ll);
                    options.icon(BitmapDescriptorFactory.fromResource(R.drawable.favouritelocation_dropper));
                    mMap.addMarker(options);
                }
    }
}