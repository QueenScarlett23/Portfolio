package com.a19013147.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ProgressBar;
import android.widget.Switch;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import static com.google.android.material.internal.ContextUtils.getActivity;

public class Settings extends AppCompatActivity {

    Switch SwitchNighMode, SwitchMetric;
    Button ButtonBack;
    boolean saved = true;

    ProgressBar pBar;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        Toast.makeText(this, GetStrFromPrefs(LoginActivity.NAME) + "", Toast.LENGTH_SHORT).show();

        mAuth = FirebaseAuth.getInstance();

        pBar = findViewById(R.id.pBarSettings);

        ButtonBack = findViewById(R.id.buttonBack);
        ButtonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //ToMapsActivity();
                SaveandExit();
            }
        });

        SwitchNighMode = findViewById(R.id.SwitchNightMode);
        SwitchMetric = findViewById(R.id.switchMetric);

        // setting switch to right setting to show
        SwitchNighMode.setChecked(GetBoolFromPrefs(LoginActivity.NIGHTMODE));
        // setting switch to right setting to show
        SwitchMetric.setChecked(GetBoolFromPrefs(LoginActivity.METRIC));

        // setting saved boolean to false if data is changed
        SwitchNighMode.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                saved = false;
            }
        });
        SwitchMetric.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                saved = false;
            }
        });

        /*ButtonSave = findViewById(R.id.buttonSave);
        ButtonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // saving data in case of restart
                SaveToPrefs(SwitchNighMode.isChecked(), SwitchMetric.isChecked());

                PushToDataBase(false);
            }
        });*/
    }
    private void SaveandExit() {
        if (saved) {

            ToMapsActivity();

        } else {

            AlertDialog.Builder builder = new AlertDialog.Builder(Settings.this);
            builder.setMessage(R.string.confirm_setting_save_dialog_message)
                    .setTitle(R.string.confirm_dialog_settings_back_title)
                    .setPositiveButton(R.string.confirm_save, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            // CONFIRM
                            // saving data in case of restart
                            SaveToPrefs(SwitchNighMode.isChecked(), SwitchMetric.isChecked());
                            //save to database
                            PushToDataBase(true); // true sends activity to Mapds activity on completeion
                        }
                    })
                    .setNegativeButton(R.string.Dont_save_settings, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            // CANCEL
                            // Move to Maps Activity
                            ToMapsActivity();
                        }

                    });
            // Create the AlertDialog object and return it
            builder.create().show();

        }
    }

    void PushToDataBase(boolean returnToMapsOnComplete) {
        pBar.setVisibility(View.VISIBLE);

        String name = GetStrFromPrefs(LoginActivity.NAME),
                email = GetStrFromPrefs(LoginActivity.EMAIL);
        boolean nightmode = GetBoolFromPrefs(LoginActivity.NIGHTMODE),
                metric = GetBoolFromPrefs(LoginActivity.METRIC);

        User user = new User (name, email, nightmode, metric);
        FirebaseDatabase.getInstance().getReference("Users")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                .child("metric")
                .setValue(user.metric);
        FirebaseDatabase.getInstance().getReference("Users")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                .child("nightMode")
                .setValue(user.nightMode).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    Toast.makeText(Settings.this, "Saved successfully", Toast.LENGTH_LONG).show();
                    pBar.setVisibility(View.GONE);

                    // set saved to true
                    saved = true;

                    // apply night mode (restarts app of changed)
                    ApplyNightMode(SwitchNighMode.isChecked());

                    if (returnToMapsOnComplete)
                        ToMapsActivity();

                } else {
                    Toast.makeText(Settings.this, "Unable to Save. Try again", Toast.LENGTH_LONG).show();
                    pBar.setVisibility(View.GONE);
                }

            }
        });
    }

    void SaveToPrefs(boolean night, boolean metric) {

        SharedPreferences sharedPref = this.getSharedPreferences("com.a19013147.myapplication", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();

        editor.putBoolean(LoginActivity.NIGHTMODE, night);
        editor.putBoolean(LoginActivity.METRIC, metric);

        editor.apply();
    }

    void ToMapsActivity() {
        String name = GetStrFromPrefs(LoginActivity.NAME),
                email = GetStrFromPrefs(LoginActivity.EMAIL);
        boolean nightmode = GetBoolFromPrefs(LoginActivity.NIGHTMODE),
                metric = GetBoolFromPrefs(LoginActivity.METRIC);

        IntentHelper.openIntent(Settings.this, MapsActivity.class, LoginActivity.NAME, name, LoginActivity.EMAIL, email, LoginActivity.NIGHTMODE, nightmode, LoginActivity.METRIC, metric);
    }

    private boolean GetBoolFromPrefs(String s) {
        SharedPreferences sharedPref = this.getSharedPreferences("com.a19013147.myapplication", Context.MODE_PRIVATE);
        return sharedPref.getBoolean(s, false);
    }
    private String GetStrFromPrefs(String s) {
        SharedPreferences sharedPref = this.getSharedPreferences("com.a19013147.myapplication", Context.MODE_PRIVATE);
        return sharedPref.getString(s, "");
    }

    void ApplyNightMode(boolean nightmode) {

        if (nightmode) {
            AppCompatDelegate
                    .setDefaultNightMode(
                            AppCompatDelegate
                                    .MODE_NIGHT_YES);
        } else {
            AppCompatDelegate
                    .setDefaultNightMode(
                            AppCompatDelegate
                                    .MODE_NIGHT_NO);
        }
    }

    // make sure data is not lost
    @Override
    public void onBackPressed () {
        SaveandExit();
    }
}