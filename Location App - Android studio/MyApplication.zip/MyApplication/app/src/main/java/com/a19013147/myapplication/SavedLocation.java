package com.a19013147.myapplication;

import com.google.android.gms.maps.model.LatLng;

public class SavedLocation {
    public String placeID, info;
    public double position_lat, position_lng;

    public SavedLocation () {

    }

    public SavedLocation (String placeID, String info, LatLng position) {
        this.placeID = placeID;
        this.position_lat = position.latitude;
        this.position_lng = position.longitude;
        this.info = info;
    }
}
