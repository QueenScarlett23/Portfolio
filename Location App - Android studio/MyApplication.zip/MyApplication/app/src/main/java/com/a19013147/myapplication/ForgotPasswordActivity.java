package com.a19013147.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class ForgotPasswordActivity extends AppCompatActivity {

    Button ResetPasswordButton;
    EditText etEmail;
    ProgressBar pBar;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        mAuth = FirebaseAuth.getInstance();

        etEmail = findViewById(R.id.etEmailReset);
        pBar = findViewById(R.id.pBarReset);

        ResetPasswordButton = findViewById(R.id.btnSubmitReset);
        ResetPasswordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Submit();
            }
        });
    }

    void Submit() {
        String email;
        email = etEmail.getText().toString().trim();

        // validation
        if (email.isEmpty()) {
            etEmail.setError("Field must not be blank");
            etEmail.requestFocus();
            return;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Enter a valid email");
            etEmail.requestFocus();
            return;
        }

        // submission
        pBar.setVisibility(View.VISIBLE);
        ResetPassword(email);
    }

    void ResetPassword(String email) {
        mAuth.sendPasswordResetEmail(email).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {

                if (task.isSuccessful()) {
                    Toast.makeText(ForgotPasswordActivity.this, "Check your email", Toast.LENGTH_LONG).show();
                    IntentHelper.openIntent(ForgotPasswordActivity.this, LoginActivity.class);
                } else {
                    Toast.makeText(ForgotPasswordActivity.this, "Try again!", Toast.LENGTH_LONG).show();
                }
                pBar.setVisibility(View.GONE);
            }
        });
    }
}