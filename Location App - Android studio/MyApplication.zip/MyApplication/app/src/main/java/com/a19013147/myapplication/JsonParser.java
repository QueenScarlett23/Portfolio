package com.a19013147.myapplication;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class JsonParser {
    private HashMap<String, String> parseJsonObject(JSONObject object) {
        HashMap<String, String> datalist = new HashMap<>();
        try {
            String name = "";
            String latitude = "";
            String longitude = "";
            String place_id = "";
            String rating = "";
            String openHours = "";

            try {
                name = object.getString("name");
            } catch (Exception ex) {

            }
            try {
                latitude = object.getJSONObject("geometry")
                        .getJSONObject("location").getString("lat");
            } catch (Exception ex) {

            }
            try {
                longitude = object.getJSONObject("geometry")
                        .getJSONObject("location").getString("lng");
            } catch (Exception ex) {

            }
            try {
                place_id = object.getString("place_id");
            } catch (Exception ex) {

            }
            try {
                rating = object.getString("rating");
            } catch (Exception ex) {

            }
            try {
                openHours = object.getJSONObject("opening_hours").getString("open_now");
            } catch (Exception ex) {

            }

            datalist.put("name", name);
            datalist.put("lat", latitude);
            datalist.put("lng", longitude);
            datalist.put("place_id", place_id);
            datalist.put("rating", rating);
            datalist.put("open_now", openHours);
            datalist.put("place_id", place_id);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return datalist;
    }

    private List<HashMap<String, String>> parseJsonArray(JSONArray jsonArray) {
        List<HashMap<String, String>> dataList = new ArrayList<>();

        for (int i = 0; i < jsonArray.length(); i++) {
            try {
                HashMap<String, String> data = parseJsonObject((JSONObject) jsonArray.get(i));
                dataList.add(data);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        return dataList;
    }

    public List<HashMap<String, String>> parseResult(JSONObject object) {
        JSONArray jsonArray1 = null;
        try {
            jsonArray1 = object.getJSONArray("results");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return parseJsonArray(jsonArray1);
    }
}
