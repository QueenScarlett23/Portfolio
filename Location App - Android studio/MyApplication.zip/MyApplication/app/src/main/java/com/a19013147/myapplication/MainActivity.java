package com.a19013147.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    private Button btnToggleDark;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnToggleDark = findViewById(R.id.btnToggleDark);
        btnToggleDark.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view)
                    {
                        ToSettings();
                    }
                });

        //Logout();

        IntentHelper.openIntent(this, LoginActivity.class);
        //IntentHelper.openIntent(this, Drawer.class);
        //ToSettings();
    }

    // sends user to settings
    void ToSettings() {
        IntentHelper.openIntent(this, Settings.class);
    }

    // loads settings from user prefs
    void LoadSettings() {
        AppCompatDelegate
                .setDefaultNightMode(
                        AppCompatDelegate
                                .MODE_NIGHT_YES);
    }

    void Logout() {
        // resetting user prefs
        SharedPreferences sharedPref = this.getSharedPreferences("com.a19013147.myapplication", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();

        editor.putBoolean(LoginActivity.LOGGED, false);
        editor.putString(LoginActivity.NAME, "");
        editor.putString(LoginActivity.EMAIL, "");
        editor.putBoolean(LoginActivity.NIGHTMODE, false);
        editor.putBoolean(LoginActivity.METRIC, false);

        editor.apply();
        editor.commit();
        // loging out mAuth
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        mAuth.signOut();

        // goinmg to login screen
        IntentHelper.openIntent(this, LoginActivity.class);
    }
}