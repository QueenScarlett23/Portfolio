package com.a19013147.myapplication;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class User {

    public String Name, Email, Username;

    // settings
    public boolean nightMode, metric;
    private boolean encrpyted;
    public ArrayList<SavedLocation> FavouriteLocations = new ArrayList<SavedLocation>();

    public User() {

    }

    public User(String Name, String Email) {
        this.Name = Name;
        this.Email = Email;
        nightMode = false;
        metric = false;
        encrpyted = false;
    }

    public User(String Name, String Email, boolean nighMode, boolean metric) {
        this.Name = Name;
        this.Email = Email;
        this.nightMode = nighMode;
        this.metric = metric;
        encrpyted = false;
    }

    /*public void AddFavourite(LatLng newPlace) {
        if (FavouritePlaces == null) {
            FavouritePlaces = new ArrayList<LatLng>();
            FavouritePlaces.add(newPlace);
        } else {
            FavouritePlaces.add(newPlace);
        }
    }*/

    public boolean isEncrpyted() {
        return encrpyted;
    }

    // encrypts all data in user
    public void EncryptAll() {
        if (!encrpyted) {
            Name = Encrypt(Name);
            Email = Encrypt(Email);
            encrpyted = true;
        }
    }

    // Decrypts all data in user
    public void DecryptAll() {
        if (encrpyted) {
            Name = Decrypt(Name);
            Email = Decrypt(Email);
            encrpyted = false;
        }
    }

    private static int k = 6;

    public static String Encrypt(String s) {
        String encrypted = "";
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            int ascii = (int) c;
            ascii += k;
            encrypted += (char) ascii;
        }

        return encrypted;
    }

    public static String Decrypt(String s) {
        String decrypted = "";
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            int ascii = (int) c;
            ascii -= k;
            decrypted += (char) ascii;
        }

        return decrypted;
    }

    public void SaveLocation(String id, String info, LatLng pos) {
       /* if (FavouriteLocations == null) {
            FavouriteLocations = new SavedLocation[1];
            FavouriteLocations[0] =  new SavedLocation(id, info, pos);
        }
        else*/
        if (!IsLocationSaved(id)) {
            FavouriteLocations.add(new SavedLocation(id, info, pos));
            /*SavedLocation[] temp = new SavedLocation[FavouriteLocations.length + 1];
            for (int i = 0; i < FavouriteLocations.length; i++) {
                temp[i] = FavouriteLocations[i];
            }
            temp[FavouriteLocations.length] = new SavedLocation(id, info, pos);
*/
        }
    }

    public void RemoveLocation(String id) {
        for (SavedLocation sl : FavouriteLocations) {
            if (id.equals(sl.placeID)) {
                FavouriteLocations.remove(sl);
                /*SavedLocation[] temp = new SavedLocation[FavouriteLocations.si - 1];
                for (int i = 0; i < FavouriteLocations.length; i++) {
                    temp[i] = FavouriteLocations[i];
                }*/
                break;
            }
        }
    }

    public boolean IsLocationSaved(String id) {
        if (FavouriteLocations == null) {
            FavouriteLocations = new ArrayList<SavedLocation>();
            return false;
        }else if(FavouriteLocations.size() < 1) {
            return false;
        }
        for (SavedLocation sl : FavouriteLocations) {
            if (id.equals(sl.placeID)) {
                return true;
            }
        }
        return false;
    }
}
