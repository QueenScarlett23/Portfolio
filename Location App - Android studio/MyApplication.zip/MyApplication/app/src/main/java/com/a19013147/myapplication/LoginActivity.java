package com.a19013147.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.FirebaseDatabase;

public class LoginActivity extends AppCompatActivity {

    EditText Username, Password;
    Button btnLogin;
    TextView ForgotPassword, Register;
    ProgressBar pBar;

    private FirebaseAuth mAuth;

    public static String NAME = "name";
    public static String EMAIL = "email";
    public static String NIGHTMODE = "nightmode";
    public static String METRIC = "metric";
    public static String LOGGED = "logged";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mAuth = FirebaseAuth.getInstance();

        // check if logged in
        if (GetBoolFromPrefs(LOGGED))
        {
            // applying nightmode
            ApplyNightMode(GetBoolFromPrefs(NIGHTMODE));

            IntentHelper.openIntent(LoginActivity.this, MapsActivity.class);
        }

        pBar = findViewById(R.id.pBarLogin);
        Username = findViewById(R.id.etUsernameLogin);
        Password = findViewById(R.id.etPassword);

        btnLogin = findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Login();
            }
        });

        ForgotPassword = findViewById(R.id.tvForgotPassword);
        ForgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ForgoPassword();
            }
        });

        Register = findViewById(R.id.tvRegisterText);
        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ToRegister();
            }
        });

    }

    public boolean GetBoolFromPrefs(String s) {
        SharedPreferences sharedPref = this.getSharedPreferences("com.a19013147.myapplication", Context.MODE_PRIVATE);
        return sharedPref.getBoolean(s, false);
    }
    private String GetStrFromPrefs(String s) {
        SharedPreferences sharedPref = this.getSharedPreferences("com.a19013147.myapplication", Context.MODE_PRIVATE);
        return sharedPref.getString(s, "");
    }

    void ApplyNightMode(boolean nightmode) {
        if (nightmode) {
            AppCompatDelegate
                    .setDefaultNightMode(
                            AppCompatDelegate
                                    .MODE_NIGHT_YES);
        } else {
            AppCompatDelegate
                    .setDefaultNightMode(
                            AppCompatDelegate
                                    .MODE_NIGHT_NO);
        }
    }

    void SaveToPrefs(User us) {
        // shared pref
        SharedPreferences sharedPref = this.getSharedPreferences("com.a19013147.myapplication", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        // setting prefs
        editor.putBoolean(LoginActivity.NIGHTMODE, us.nightMode);
        editor.putBoolean(LoginActivity.LOGGED, true);
        editor.putBoolean(LoginActivity.METRIC, us.metric);
        editor.putString(LoginActivity.NAME, us.Name);
        editor.putString(LoginActivity.EMAIL, us.Email);
        // saving
        editor.apply();
    }

    // logs user in
    void Login() {
        // validation
        String username = Username.getText().toString().trim();
        String password = Password.getText().toString().trim();

        if (username.isEmpty()) {
            Username.setError("Username required");
            Username.requestFocus();
            return;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(username).matches()) {
            Username.setError("valid email required");
            Username.requestFocus();
            return;
        }


        if (password.isEmpty()) {
            Password.setError("Password required");
            Password.requestFocus();
            return;
        }

        if (password.length() < 6) {
            Password.setError("Password incorect");
            Password.requestFocus();
            return;
        }

        // login
        pBar.setVisibility(View.VISIBLE);

        mAuth.signInWithEmailAndPassword(username, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    // redirect

                    try {


                    FirebaseDatabase.getInstance().getReference("Users")
                            .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                            .get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DataSnapshot> task) {

                            if (task.isSuccessful()) {
                                DataSnapshot ds = task.getResult();
                                User user = ds.getValue(User.class);
                                SaveToPrefs(user);

                                // passing data on to main fragment
                                IntentHelper.openIntent(LoginActivity.this, MapsActivity.class, NAME, user.Name, EMAIL, user.Email, NIGHTMODE, user.nightMode, METRIC, user.metric);

                            } else {
                                Toast.makeText(LoginActivity.this, "Unable to login. Try again!", Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                    } catch (Exception e) {

                    }
                } else {
                    Toast.makeText(LoginActivity.this, "Incorect Login Credentials", Toast.LENGTH_LONG).show();
                    Username.requestFocus();
                }
                pBar.setVisibility(View.GONE);
            }
        });
    }

    // user forgot their password
    void ForgoPassword() {
        IntentHelper.openIntent(this, ForgotPasswordActivity.class);
    }

    // takes user to Register
    void ToRegister() {
        IntentHelper.openIntent(this, RegisterActivity.class);
    }

    // prevent users from trying to break app
    @Override
    public void onBackPressed () {
    }
}