package com.a19013147.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterActivity extends AppCompatActivity {

    TextView toLogin;
    Button Register;
    EditText etName, etEmail, etPassword_1, etPassword_2;
    ProgressBar pBar;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mAuth = FirebaseAuth.getInstance();

        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPassword_1 = findViewById(R.id.etPassword_1);
        etPassword_2 = findViewById(R.id.etPassword_2);
        pBar = findViewById(R.id.pBarRegister);

        toLogin = findViewById(R.id.tvBackToLogin);
        toLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GoToLogin();
            }
        });

        Register = findViewById(R.id.btnRegister);
        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Register();
            }
        });

    }

    void Register() {
        String name = etName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password_1 = etPassword_1.getText().toString().trim();
        String password_2 = etPassword_2.getText().toString().trim();

        // data validation
        if (name.isEmpty()) {
            etName.setError("Full Name Required");
            etName.requestFocus();
            return;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Please enter a valid email");
            etEmail.requestFocus();
            return;
        }
        if (password_1.isEmpty()) {
            etPassword_1.setError("Password Required");
            etPassword_1.requestFocus();
            return;
        }
        if (password_1.length() < 6) {
            etPassword_1.setError("Password of at least 6 characters Required");
            etPassword_1.requestFocus();
            return;
        }
        if (!password_1.equals(password_2)) {
            etPassword_2.setError("Mathching Passwords Required");
            etPassword_2.requestFocus();
            return;
        }

        // register
        pBar.setVisibility(View.VISIBLE);
        mAuth.createUserWithEmailAndPassword(email, password_1)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if (task.isSuccessful()) {

                            User user = new User(name, email);

                            FirebaseDatabase.getInstance().getReference("Users")
                                    .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                    .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        Toast.makeText(RegisterActivity.this, "User registered successfully", Toast.LENGTH_LONG).show();
                                        IntentHelper.openIntent(RegisterActivity.this, LoginActivity.class);
                                        pBar.setVisibility(View.GONE);

                                    } else {
                                        Toast.makeText(RegisterActivity.this, "Email already in use. Try again", Toast.LENGTH_LONG).show();
                                        pBar.setVisibility(View.GONE);
                                    }

                                }
                            });
                        } else {
                            Toast.makeText(RegisterActivity.this, "Unable to register user. Try again", Toast.LENGTH_LONG).show();
                            pBar.setVisibility(View.GONE);
                        }
                    }
                });
    }

    // sends user to Login
    void GoToLogin() {
        IntentHelper.openIntent(this, LoginActivity.class);
    }
}